package com.sinh.message

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Black = Color(0xFF121212)
private val Panel = Color(0xFF1E1E1E)
private val Gold = Color(0xFFD6AD50)
private val Muted = Color(0xFFAAAAAA)
private val White = Color(0xFFF7F4EC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SinhMessageApp() }
    }
}

private enum class Tab { Chats, Search, Profile }

@Composable
fun SinhMessageApp() {
    var language by remember { mutableStateOf("ខ្មែរ") }
    var tab by remember { mutableStateOf(Tab.Chats) }
    var signedIn by remember { mutableStateOf(false) }
    val kh = language == "ខ្មែរ"

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold, onPrimary = Black, background = Black,
            surface = Panel, onSurface = White, secondary = Gold
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Black) {
            if (!signedIn) {
                LoginScreen(kh, onLanguage = { language = it }, onDemoLogin = { signedIn = true })
            } else {
                Scaffold(
                    containerColor = Black,
                    topBar = {
                        Row(
                            Modifier.fillMaxWidth().background(Panel).padding(horizontal = 20.dp, vertical = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Sinh", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                            Text(" Message", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.weight(1f))
                            Text(language, color = Gold, modifier = Modifier.clickable {
                                language = if (kh) "English" else "ខ្មែរ"
                            }.padding(8.dp))
                        }
                    },
                    bottomBar = {
                        NavigationBar(containerColor = Panel, contentColor = Gold) {
                            NavigationBarItem(selected = tab == Tab.Chats, onClick = { tab = Tab.Chats },
                                icon = { Icon(Icons.Default.Chat, null) }, label = { Text(if (kh) "សារ" else "Chats") })
                            NavigationBarItem(selected = tab == Tab.Search, onClick = { tab = Tab.Search },
                                icon = { Icon(Icons.Default.Search, null) }, label = { Text(if (kh) "ស្វែងរក" else "Search") })
                            NavigationBarItem(selected = tab == Tab.Profile, onClick = { tab = Tab.Profile },
                                icon = { Icon(Icons.Default.Person, null) }, label = { Text(if (kh) "គណនី" else "Profile") })
                        }
                    }
                ) { padding ->
                    Box(Modifier.padding(padding)) {
                        when (tab) {
                            Tab.Chats -> ChatsScreen(kh)
                            Tab.Search -> SearchScreen(kh)
                            Tab.Profile -> ProfileScreen(kh, onLogout = { signedIn = false })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LoginScreen(kh: Boolean, onLanguage: (String) -> Unit, onDemoLogin: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(92.dp).background(Panel, RoundedCornerShape(28.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Forum, contentDescription = null, tint = Gold, modifier = Modifier.size(48.dp))
        }
        Spacer(Modifier.height(20.dp))
        Text("Sinh Message", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(if (kh) "ភ្ជាប់ទំនាក់ទំនងជាមួយមិត្តភក្តិ" else "Connect with your friends",
            color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(42.dp))
        Button(
            onClick = onDemoLogin,
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black),
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(14.dp)
        ) {
            Icon(Icons.Default.AccountCircle, null)
            Spacer(Modifier.width(10.dp))
            Text(if (kh) "បន្តជាមួយ Google (សាកល្បង)" else "Continue with Google (Demo)",
                fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(18.dp))
        Text(if (kh) "ភាសា៖ ខ្មែរ  |  English" else "Language: English  |  Khmer",
            color = Muted, modifier = Modifier.clickable { onLanguage(if (kh) "English" else "ខ្មែរ") }.padding(12.dp))
        Spacer(Modifier.height(28.dp))
        Text(if (kh) "ការចូល Google ពិតប្រាកដត្រូវការកំណត់ Firebase" else "Real Google sign-in requires Firebase setup",
            color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun ChatsScreen(kh: Boolean) {
    val chats = listOf(
        Triple("Sokha", if (kh) "សួស្តី! សុខសប្បាយទេ?" else "Hello! How are you?", "10:42"),
        Triple("Dara", if (kh) "បានទទួលសារហើយ" else "Message received", "09:18"),
        Triple("Friends Group", if (kh) "ថ្ងៃនេះជួបគ្នាម៉ោងប៉ុន្មាន?" else "What time shall we meet?", "Yesterday")
    )
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text(if (kh) "ការសន្ទនា" else "Messages", color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(chats) { item ->
                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).background(Gold, CircleShape), contentAlignment = Alignment.Center) {
                        Text(item.first.take(1), color = Black, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.first, color = White, fontWeight = FontWeight.SemiBold)
                        Text(item.second, color = Muted, fontSize = 13.sp)
                    }
                    Text(item.third, color = Gold, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun SearchScreen(kh: Boolean) {
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text(if (kh) "ស្វែងរកមិត្តភក្តិ" else "Find friends", color = White,
            fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text(if (kh) "Username, Gmail ឬលេខទូរស័ព្ទ" else "Username, Gmail or phone number") },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = Gold) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = White, unfocusedTextColor = White,
                focusedBorderColor = Gold, unfocusedBorderColor = Muted,
                focusedPlaceholderColor = Muted, unfocusedPlaceholderColor = Muted
            )
        )
        Spacer(Modifier.height(12.dp))
        Text(if (kh) "វាយបញ្ចូលដើម្បីស្វែងរកអ្នកប្រើប្រាស់" else "Enter a detail to search for users",
            color = Muted, fontSize = 13.sp)
    }
}

@Composable
private fun ProfileScreen(kh: Boolean, onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(28.dp))
        Box(Modifier.size(88.dp).background(Gold, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Person, null, tint = Black, modifier = Modifier.size(52.dp))
        }
        Spacer(Modifier.height(14.dp))
        Text(if (kh) "អ្នកប្រើប្រាស់ Sinh" else "Sinh user", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text("username@gmail.com", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(32.dp))
        OutlinedButton(onClick = onLogout, colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)) {
            Icon(Icons.Default.Logout, null)
            Spacer(Modifier.width(8.dp))
            Text(if (kh) "ចាកចេញ" else "Log out")
        }
    }
}
