# Sinh Message – Android Starter

គម្រោងចាប់ផ្តើម Android ដោយ Kotlin និង Jetpack Compose សម្រាប់ UI របស់ Sinh Message។

## មានអ្វីខ្លះ
- រចនាបថខ្មៅ និងមាស
- ភាសាខ្មែរ និង English (ប្ដូរតាមប៊ូតុងភាសា)
- ផ្ទាំង Login (ប៊ូតុង Google ជា Demo ប៉ុណ្ណោះ)
- ផ្ទាំង Chats, Search និង Profile
- ស្វែងរកតាម Username, Gmail និងលេខទូរស័ព្ទ (UI ប៉ុណ្ណោះ)

## បើកគម្រោង
1. ដំឡើង Android Studio។
2. Extract ZIP នេះ។
3. បើក folder `SinhMessage_Android_Starter` ក្នុង Android Studio។
4. រង់ចាំ Gradle Sync រួច Run លើ Emulator ឬ Android phone។

## ចំណាំសំខាន់
នេះជាគំរូ UI ដំបូង មិនទាន់ជា chat app ពិតប្រាកដទេ។
ប៊ូតុង Google បច្ចុប្បន្នគ្រាន់តែចូលទៅ Demo screen មិនទាន់ធ្វើ Google authentication។
ការផ្ញើ/ទទួលសារ, ការស្វែងរកអ្នកប្រើប្រាស់ពិតប្រាកដ និង push notifications ត្រូវការភ្ជាប់ Firebase (Authentication, Cloud Firestore, Cloud Messaging), កំណត់ Firebase project និង Android SHA fingerprints / OAuth credentials។
កុំដាក់ password ឬ secret key ក្នុង source code។
